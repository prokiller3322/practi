$(function(){
	var brand = new Vue({
		el:'.content .brand_logo',
		data:function(){
			return{
				logochange:[
					{
						'transform':'rotateY(180deg)',
						'transition-delay': ''
					},
					{
						'transform':'rotateY(180deg)',
						'transition-delay': ''
					},
					{
						'transform':'',
						'transition-delay': ''
					}],
				logoset:['','','','','','','','',''],
				num:1,
				// changeimg2:[
				// 	require('img/logo/TB1Qvu9DoH1gK0jSZSyXXXtlpXa.png'),
				// 	require('img/logo/TB1PrRDyQL0gK0jSZFtXXXQCXXa.png'),
				// 	require('img/logo/TB1TJNTPXXXXXcqXVXXSutbFXXX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB1Ul00mlfH8KJjy1XbXXbLdXXa.png'),
				// 	require('img/logo/TB1_aF7pG6qK1RjSZFmXXX0PFXa.png'),
				// 	require('img/logo/TB1a3bVRXXXXXbfXFXXXXXXXXXX.png'),
				// 	require('img/logo/TB1gD8NhDlYBeNjSszcXXbwhFXa.png'),
				// 	require('img/logo/TB1gWINIVXXXXbbXFXXSutbFXXX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB1i5tflFuWBuNjSspnXXX1NVXa.png')
				// ],
				// changeimg1:[
				// 	require('img/logo/TB1D0sLnHSYBuNjSspiXXXNzpXa.png'),
				// 	require('img/logo/TB1ilbUHpXXXXb8XXXXSutbFXXX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/O1CN019OFNEK22bFcXdLUb5_!!928417138.png_100x150q100.jpg_.webp'),
				// 	require('img/logo/T1wMh5XhVGXXb1upjX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB1123WLXXXXXX3aXXXSutbFXXX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB16oQ2IVXXXXXuXXXXSutbFXXX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB1CAsYJpXXXXbuXpXXwu0bFXXX.png_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB1Im97lVT7gK0jSZFpXXaTkpXa.png'),
				// 	require('img/logo/TB1LA6XoL5TBuNjSspmXXaDRVXa.png')
				// ],
				// img:[
				// 	require('img/logo/TB1D0sLnHSYBuNjSspiXXXNzpXa.png'),
				// 	require('img/logo/TB1ilbUHpXXXXb8XXXXSutbFXXX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/O1CN019OFNEK22bFcXdLUb5_!!928417138.png_100x150q100.jpg_.webp'),
				// 	require('img/logo/T1wMh5XhVGXXb1upjX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB1123WLXXXXXX3aXXXSutbFXXX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB16oQ2IVXXXXXuXXXXSutbFXXX.jpg_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB1CAsYJpXXXXbuXpXXwu0bFXXX.png_100x150q100.jpg_.webp'),
				// 	require('img/logo/TB1Im97lVT7gK0jSZFpXXaTkpXa.png'),
				// 	require('img/logo/TB1LA6XoL5TBuNjSspmXXaDRVXa.png')
				// ],
				// a:require('img/logo/TB1D0sLnHSYBuNjSspiXXXNzpXa.png')
			}
		},
		methods:{
			changebtn:function(){
				for(let item in this.logoset){
					this.logoset.splice(item,1,this.logochange[0]);
				}
				let ithis = this;
				setTimeout(function(){
					
					for(let item in ithis.logoset){
						ithis.logoset.splice(item,1,ithis.logochange[2]);
					}
				},1000);
			}
		}
	});
	var search = new Vue({
		el:'.content .scrollSea',
		data:function(){
			return{
				searchcss:[
					{
						'height':'50px',
						'display':'block',
					},
					{
						'height':'0px',
						'display':'none',
					}
				],
				searchset:''
			}
		},
		methods:{
			scrollshow:function(event){
				this.searchset = this.searchcss[0];
				console.log('show');
			},
			scrollhidden:function(event){
				this.searchset = this.searchcss[1];
				console.log('hidden');
			}
		},
		mounted:function(){
			let sthis = this;
			$(window).scroll(function(e){
				if(document.documentElement.scrollTop > 800){
					sthis.scrollshow();
				}else{
					sthis.scrollhidden();
				}
			});
		}
	});
});