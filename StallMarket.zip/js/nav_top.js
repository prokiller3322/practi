$(function(){
	var nav = new Vue({
		el:'.content .topper',
		data:function(){
			return{
				imgstyle:[
					{
						'opacity':0,
					},
					{
						'opacity':1,
					},
					{
						'background': '#FFFFFF',
						'opacity': .8
					},
					{
						'background': '#1F1F1F',
						'opacity': .2
					}
					],
				num:1,
				imgset:[
					{
						'opacity':1,
					},
					{
						'opacity':0,
					},
					{
						'opacity':0,
					},
					{
						'opacity':0,
					},
					{
						'opacity':0,
					}],
				liset:[
					{
						'background': '#FFFFFF',
						'opacity': .8
					},
					{
						'background': '#1F1F1F',
						'opacity': .2
					},
					{
						'background': '#1F1F1F',
						'opacity': .2
					},
					{
						'background': '#1F1F1F',
						'opacity': .2
					},
					{
						'background': '#1F1F1F',
						'opacity': .2
					},
					],
				time:''
					
			}
		},
		methods:{
			deal:function(){ //设置轮播样式
				let a = this.num-1
				this.imgset.splice(a,1,this.imgstyle[1]);
				this.liset.splice(a,1,this.imgstyle[2]);
				for(let i=0; i<this.imgset.length; i++){
					if(i == a) continue;
					this.imgset.splice(i,1,this.imgstyle[0]);
					this.liset.splice(i,1,this.imgstyle[3]);
				}
			},
			firstb:function(){
				this.num = 1;
				this.deal();
				console.log("img1");
			},
			secondb:function(){
				this.num = 2;
				this.deal();
				console.log("img2");
			},
			thirdb:function(){
				this.num = 3;
				this.deal();
				console.log("img3");
			},
			forthb:function(){
				this.num = 4;
				this.deal();
				console.log("img4");
			},
			fifthb:function(){
				this.num = 5;
				this.deal();
				console.log("img5");
			}
		},
		created:function(){
			let timthis = this;
			setInterval(function(){
			timthis.deal();
			timthis.num++;
			if(timthis.num > 5) timthis.num = 1;
			},2000);
		},
	});
});