$(function(){ 
	var hea = new Vue({
		el:'.header .right_b',
		components:{
			'my-block':{ 
				template : `<div>
								<p v-for="item in jub">{{item}}</p>
							</div>`,
				props:['jub']
			},
			'store-support':{
				template:`<ul>
							<li v-for="(name,item) in storesuppda">
								<h3 >{{name.name}}</h3>
								<p v-for="(num,key) in name.content">{{num}}</p>
							</li>
						</ul>`,
				props:['storesuppda']
			},
			'web-nav':{
				template:`<div>
							<div v-for="(obj,item) in webnavdat">
								<ul>
									<h2>{{obj.name}}</h2>
									<li v-for="num in obj.content">
										<p>{{num}}</p>
									</li>
								</ul>
							</div>
						</div>`,
				props:['webnavdat']
			}
		},
		data:function(){
			return{
				myBlock:['我买进的货','我卖出的货'],
				myMarks:['我收藏的货物','我收藏的摊位'],
				jub:'',
				storesuppda:[
					{
						name:'商家：',
						content:['商家中心','天猫规则','商家入驻','运营服务','商家品控','商家工具','天猫智库','喵言喵语']},
					{
						name:'帮助：',
						content:['帮助中心','问友商']}],
				webnavdat:[
					{
						name:'热点推荐 Hot',
						content:['天猫超市','喵鲜生','科技新品','女装新品','酷玩街','内衣新品','试美妆','运动新品','时尚先生',
						'精明妈咪','吃乐会','企业采购','会员积分','天猫国际','品质频道']},
					{
						name:'行业市场 Market',
						content:['美妆','电器','女装','男装','女鞋','男鞋','内衣','箱包','运动',
						'母婴','家装','医药','食品','配饰','汽车']
					},
					{
						name:'服务指南 Help',
						content:['帮助中心','品质保障','特色服务','7天退换货']
					}
					]
			}
		},
		computed:{
			
		},
		methods:{
			blockt:function(){
				this.jub = this.myBlock;
			},
			blockf:function(){
				this.jub = this.myMarks;
			}
		}
	});
	
	


});